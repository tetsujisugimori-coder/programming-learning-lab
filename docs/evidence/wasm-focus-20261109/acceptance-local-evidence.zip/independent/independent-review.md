# 独立再レビュー（ローカル検証完了、提出HEAD・CI照合待ち）

対象ローカルcommit: 16099ef0503c14a04f3efb2d1247b55af5c4f6f0
対象tree: ed82d47e29c3eb156ef373f55c55e870d30214dd
比較元: 34422bf6736a16435247c8898214fb0c07429555

## 結果
今回の修正範囲で残存するコード指摘なし。提出HEADの一致と最終CI原成果物の確認は未完了。

- 基準commitを別ディレクトリに展開・buildし、Python lesson/chapters復帰の独自試験を16条件で実行。32/32が実際に失敗し、すべてでhidden祖先を持つ非表示対象へのfocus()を観測した。
- 初版修正の#main履歴復帰では全16条件でBODYへ戻り、mainのフォーカスに失敗。初版テストの「hiddenでない」だけの判定では検出できなかった。16099efでは明示的なmainフォーカスと厳密な期待値へ修正済み。
- 16099efを別ディレクトリへ固定展開して再build。4独自シナリオ×16条件の64/64がPASS。非表示対象へのfocus()は0、終了時のhiddenフォーカスも0。
- 条件はChromium 141.0.7390.37 / WebKit 26.0 × 375/390/765/1280 × no-preference/reduce。ローカル補助試験はPlaywright 1.56.1。固定依存1.58.2のCIとは区別する。
- Pythonのノード同一性、メモ、読了、PC実行自己申告、正解済みクイズ、開いたヒント、分割幅の保持を確認。#main履歴復帰・Forward・Wasm各節/章一覧・Python復帰を検査。
- 16条件すべてで本物のWorkerを起動し、移動時のterminateを観測。停止済みWorkerから保存したonmessage/onerrorを明示的に呼び、移動後と新しい無限ループWorkerの実行中の両方で古い成功/失敗通知が無視されることを確認。新しいWorkerを停止後、標準コードで5を正常出力。
- hashchangeの登録はmain.tsの1か所のみ。routeWasmによる停止・可視性更新の後で対象コースのfocusを呼ぶ明示的な順序。登録順の交換やsetTimeoutによる偶然の順序へ依存していない。
- npm run check PASS（lint/typecheck/単体13件/build）。Python 3.12.14で9正常例と1意図エラーPASS。
- curriculum.ts、components.ts、wasm-worker.ts、wasm-curriculum.ts、package-lock.jsonは基準のhashと一致。before ZIP 48項目はSHA256台帳と一致。

実機iPhone Safari、物理キーボード、VoiceOverは未検証。Draft維持。マージ・Draft解除・自動マージ・デプロイは実施しない。
