import { chromium, webkit } from '/tmp/castle2d-pw/node_modules/playwright/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';
const phase = process.argv[2] || 'before';
const out = resolve('review',phase); await mkdir(out,{recursive:true});
const server = createServer(async(req,res)=>{try {const path=resolve(process.env.REVIEW_DIST || 'dist', `.${new URL(req.url,'http://localhost').pathname === '/' ? '/index.html' : new URL(req.url,'http://localhost').pathname}`);await stat(path);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css'})[extname(path)]||'application/octet-stream');res.end(await readFile(path));}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=`http://127.0.0.1:${server.address().port}`;
const results=[];
async function until(page,fn){await page.waitForFunction(fn,null,{timeout:3000});}
async function focused(page,sel){await page.waitForFunction(s=>document.activeElement===document.querySelector(s)&&!document.activeElement.closest('[hidden]'),sel,{timeout:3000});}
async function navigate(page,hash){await page.evaluate(h=>location.hash=h,hash);await page.waitForTimeout(70);}
try {
for(const [engine,launcher,executablePath] of [['chromium',chromium,'/tmp/castle2d-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell'],['webkit',webkit,'/tmp/castle2d-webkit.sh']]){
 const browser=await launcher.launch({headless:true,executablePath});
 for(const width of [375,390,765,1280])for(const reducedMotion of ['no-preference','reduce']){
 const context=await browser.newContext({viewport:{width,height:950},reducedMotion});
 await context.addInitScript(()=>{
  window.reviewFocus=[];window.reviewWorkers=[];
  const orig=HTMLElement.prototype.focus;HTMLElement.prototype.focus=function(o){const item={hash:location.hash,target:this.id||this.tagName,hidden:!!this.closest('[hidden]'),rendered:!!this.getClientRects().length};orig.call(this,o);window.reviewFocus.push({...item,active:document.activeElement?.id||document.activeElement?.tagName});};
  const Original=window.Worker;window.Worker=class extends Original { constructor(...args){super(...args);this.reviewTerminated=false;window.reviewWorkers.push(this);}terminate(){this.reviewTerminated=true;super.terminate();} };
 });
 const cases=phase==='before'?['lesson-return','chapters-return']:['lesson-return','chapters-return','state-history','worker-stale'];
 for(const name of cases.filter(n=>!process.env.REVIEW_CASE||n===process.env.REVIEW_CASE)){const page=await context.newPage();const result={engine,browser:browser.version(),width,reducedMotion,name};
 try {
  await page.goto(`${base}/#py-ch01-goals`);
  if(name==='lesson-return'||name==='chapters-return'){
   if(name==='chapters-return')await navigate(page,'#chapters');
   await page.getByRole('link',{name:'WebAssembly 基本編',exact:true}).click();await focused(page,'[data-wasm-lesson="0"] h2');
   await navigate(page,name==='chapters-return'?'#chapters':'#py-ch01-goals');
   await focused(page,name==='chapters-return'?'#chapters-title':'#py-ch01-goals-title');
  }
  if(name==='state-history'){
   await navigate(page,'#py-ch01-setup');
   const lesson=page.locator('#py-ch01-setup');
   await lesson.locator('textarea').fill('Independent Python preserved');
   await lesson.locator('[data-record="read"]').check();await lesson.locator('[data-record="pc"]').check();
   await lesson.locator('.quiz input[value="1"]').check();await lesson.locator('.quiz button').click();
   await lesson.locator('[data-hint="0"] summary').click();await lesson.locator('[data-hint="1"] summary').click();
   if(width===1280){await lesson.locator('.split-handle').focus();await page.keyboard.press('ArrowRight');assert.equal(await lesson.locator('.split-handle').getAttribute('aria-valuenow'),'55');}
   await page.evaluate(()=>{window.reviewPython=document.querySelector('#py-ch01-setup');window.reviewSnapshot={state:document.querySelector('.sidebar-progress').textContent,quiz:document.querySelector('#py-ch01-setup .quiz').textContent,split:document.querySelector('#py-ch01-setup .split-handle').getAttribute('aria-valuenow')};});
   await page.locator('.skip').focus();await page.keyboard.press('Enter');await focused(page,'#main');
   await page.getByRole('link',{name:'WebAssembly 基本編',exact:true}).click();await focused(page,'[data-wasm-lesson="0"] h2');
   await page.goBack();await page.waitForTimeout(80);await focused(page,'#main');
   assert.equal(await page.locator('#wasm-course').isVisible(),false);
   assert.equal(await page.locator('#main').isVisible(),true);
   assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('[hidden]')),false);
   await page.goForward();await focused(page,'[data-wasm-lesson="0"] h2');
   await navigate(page,'#wasm-2');await focused(page,'[data-wasm-lesson="1"] h2');
   await navigate(page,'#wasm-chapters');await focused(page,'#wasm-chapters h2');
   await navigate(page,'#py-ch01-setup');await focused(page,'#py-ch01-setup-title');
   assert.equal(await lesson.locator('textarea').inputValue(),'Independent Python preserved');
   assert.equal(await lesson.locator('[data-record="read"]').isChecked(),true);assert.equal(await lesson.locator('[data-record="pc"]').isChecked(),true);
   assert.equal(await lesson.locator('[data-hint="1"]').getAttribute('open'),'');
   assert.equal(await page.evaluate(()=>window.reviewPython===document.querySelector('#py-ch01-setup')),true);
   assert.deepEqual(await page.evaluate(()=>({state:document.querySelector('.sidebar-progress').textContent,quiz:document.querySelector('#py-ch01-setup .quiz').textContent,split:document.querySelector('#py-ch01-setup .split-handle').getAttribute('aria-valuenow')})),await page.evaluate(()=>window.reviewSnapshot));
  }
  if(name==='worker-stale'){
   await navigate(page,'#wasm-1');const s=page.locator('[data-wasm-lesson="0"]');
   await s.locator('.wasm-code summary').click();
   await s.locator('.wat-editor').fill('(module (func (export "calculate") (param i32 i32) (result i32) (loop $forever br $forever) i32.const 0))');
   await s.getByRole('button',{name:'実Wasmを実行',exact:true}).click();
   await until(page,()=>window.reviewWorkers.length===1);
   await page.evaluate(()=>{window.staleSuccess=window.reviewWorkers[0].onmessage;window.staleError=window.reviewWorkers[0].onerror;});
   await page.getByRole('link',{name:'Pythonへ戻る'}).click();await focused(page,'#py-ch01-goals-title');
   assert.equal(await page.evaluate(()=>window.reviewWorkers[0].reviewTerminated),true);
   await navigate(page,'#wasm-1');
   const snapshot=await s.locator('.wasm-lab').innerText();
   await page.evaluate(()=>{window.staleSuccess({data:{ok:true,mode:'run',size:8,hex:'stale',result:999}});window.staleError({message:'stale error'});});
   assert.equal(await s.locator('.wasm-lab').innerText(),snapshot);
   await s.getByRole('button',{name:'実Wasmを実行',exact:true}).click();
   await page.evaluate(()=>{window.staleSuccess({data:{ok:true,mode:'run',size:8,hex:'stale',result:999}});window.staleError({message:'stale error'});});
   assert.equal(await s.locator('[data-wasm-action="stop"]').isEnabled(),true);assert.equal(await s.locator('.wasm-result').textContent(),'');
   await s.getByRole('button',{name:'停止',exact:true}).click();
   await s.getByRole('button',{name:'コードと実行欄を初期化'}).click();
   await s.getByRole('button',{name:'実Wasmを実行',exact:true}).click();
   await s.locator('.wasm-result').filter({hasText:'5'}).waitFor({timeout:5000});
   assert.equal(await s.locator('.wasm-result').textContent(),'5');
   assert.equal(await s.locator('.wasm-status').textContent(),'実Wasm実行成功');
  }
  const calls=await page.evaluate(()=>window.reviewFocus);assert.deepEqual(calls.filter(x=>x.hidden||!x.rendered),[]);
  result.pass=true;
 }catch(e){result.pass=false;result.error=String(e);}
 result.observed=await page.evaluate(()=>({hash:location.hash,active:document.activeElement?.id||document.activeElement?.tagName,hiddenFocus:!!document.activeElement?.closest('[hidden]'),calls:window.reviewFocus,workers:window.reviewWorkers.map(w=>({terminated:w.reviewTerminated}))}));
 results.push(result);console.log(JSON.stringify({...result,observed:undefined}));await page.screenshot({path:`${out}/${engine}-${width}-${reducedMotion}-${name}.png`});await page.close();
 }
 await context.close();
 }
 await browser.close();
}
}finally{await writeFile(`${out}/results.json`,JSON.stringify(results,null,2));server.closeAllConnections();server.close();}
console.log(JSON.stringify({phase,total:results.length,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length}));
